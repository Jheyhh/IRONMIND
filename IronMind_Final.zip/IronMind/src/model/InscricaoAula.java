package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Representa a inscricao de um aluno em uma aula.
 * Guarda a data e hora exatas em que a inscricao foi feita.
 *
 * Estrutura MVC - camada MODEL
 */
public class InscricaoAula {

    private Aluno         aluno;
    private Aula          aula;
    private LocalDateTime dataHoraInscricao;

    public InscricaoAula(Aluno aluno, Aula aula) {
        this.aluno             = aluno;
        this.aula              = aula;
        this.dataHoraInscricao = LocalDateTime.now();
    }

    // --- Getters ---
    public Aluno  getAluno() { return aluno; }
    public Aula   getAula()  { return aula; }

    public String getDataHoraFormatada() {
        return dataHoraInscricao
               .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
    }
}
