package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Representa um aluno da academia.
 * Herda os campos comuns de Pessoa (id, nome, cpf, telefone).
 *
 * Estrutura MVC - camada MODEL
 */
public class Aluno extends Pessoa {

    private LocalDate          dataNascimento;
    private String             email;
    private LocalDate          dataMatricula;
    private Plano              plano;
    private List<Frequencia>   frequencias;
    private List<InscricaoAula> inscricoes;

    public Aluno(String nome, String cpf, String telefone,
                 LocalDate dataNascimento, String email,
                 LocalDate dataMatricula, Plano plano) {

        super(nome, cpf, telefone);
        this.dataNascimento = dataNascimento;
        this.email          = email;
        this.dataMatricula  = dataMatricula;
        this.plano          = plano;
        this.frequencias    = new ArrayList<>();
        this.inscricoes     = new ArrayList<>();
    }

    @Override
    public String exibirResumo() {
        return "ID: " + getId()
             + " | " + getNome()
             + " | Plano: " + plano.getNome();
    }

    // --- Getters ---
    public LocalDate           getDataNascimento() { return dataNascimento; }
    public String              getEmail()          { return email; }
    public LocalDate           getDataMatricula()  { return dataMatricula; }
    public Plano               getPlano()          { return plano; }
    public List<Frequencia>    getFrequencias()    { return frequencias; }
    public List<InscricaoAula> getInscricoes()     { return inscricoes; }

    // --- Metodos de relacionamento ---
    public void adicionarFrequencia(Frequencia f)  { frequencias.add(f); }
    public void adicionarInscricao(InscricaoAula i){ inscricoes.add(i); }
}
