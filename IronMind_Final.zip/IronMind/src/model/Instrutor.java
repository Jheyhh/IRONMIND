package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa um instrutor da academia.
 * Herda os campos comuns de Pessoa (id, nome, cpf, telefone).
 *
 * Estrutura MVC - camada MODEL
 */
public class Instrutor extends Pessoa {

    private String     especialidade;
    private String     horarioTrabalho;
    private List<Aula> aulas;

    public Instrutor(String nome, String cpf, String telefone,
                     String especialidade, String horarioTrabalho) {
        super(nome, cpf, telefone);
        this.especialidade   = especialidade;
        this.horarioTrabalho = horarioTrabalho;
        this.aulas           = new ArrayList<>();
    }

    @Override
    public String exibirResumo() {
        return "ID: " + getId()
             + " | " + getNome()
             + " | " + especialidade;
    }

    // --- Getters ---
    public String     getEspecialidade()   { return especialidade; }
    public String     getHorarioTrabalho() { return horarioTrabalho; }
    public List<Aula> getAulas()           { return aulas; }
}
