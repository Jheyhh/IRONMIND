package model;

/**
 * Classe abstrata base para Aluno e Instrutor.
 * Gera um ID unico e automatico para cada pessoa cadastrada.
 *
 * Estrutura MVC - camada MODEL
 */
public abstract class Pessoa {

    private static int contadorId = 1;

    private int    id;
    private String nome;
    private String cpf;
    private String telefone;

    public Pessoa(String nome, String cpf, String telefone) {
        this.id       = contadorId++;
        this.nome     = nome;
        this.cpf      = cpf;
        this.telefone = telefone;
    }

    // --- Getters ---
    public int    getId()       { return id; }
    public String getNome()     { return nome; }
    public String getCpf()      { return cpf; }
    public String getTelefone() { return telefone; }

    // --- Setters ---
    public void setNome(String nome)         { this.nome     = nome; }
    public void setCpf(String cpf)           { this.cpf      = cpf; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    /** Cada subclasse define como exibe seu resumo na tela. */
    public abstract String exibirResumo();
}
