package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Representa uma aula oferecida pela academia.
 *
 * Estrutura MVC - camada MODEL
 */
public class Aula {

    private String             nome;
    private String             descricao;
    private int                duracaoMinutos;
    private LocalDateTime      horario;
    private int                capacidade;
    private Instrutor          instrutor;
    private List<InscricaoAula> inscricoes;

    public Aula(String nome, String descricao, int duracaoMinutos,
                LocalDateTime horario, int capacidade, Instrutor instrutor) {
        this.nome           = nome;
        this.descricao      = descricao;
        this.duracaoMinutos = duracaoMinutos;
        this.horario        = horario;
        this.capacidade     = capacidade;
        this.instrutor      = instrutor;
        this.inscricoes     = new ArrayList<>();
    }

    // --- Getters ---
    public String              getNome()           { return nome; }
    public String              getDescricao()      { return descricao; }
    public int                 getDuracao()        { return duracaoMinutos; }
    public LocalDateTime       getHorario()        { return horario; }
    public int                 getCapacidade()     { return capacidade; }
    public Instrutor           getInstrutor()      { return instrutor; }
    public List<InscricaoAula> getInscricoes()     { return inscricoes; }

    /** Retorna quantas vagas ainda restam nesta aula. */
    public int getVagasRestantes() {
        return capacidade - inscricoes.size();
    }

    /** Retorna true se a aula ja atingiu a capacidade maxima. */
    public boolean estaLotada() {
        return inscricoes.size() >= capacidade;
    }
}
