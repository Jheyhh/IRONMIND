package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Representa um registro de entrada de um aluno na academia.
 * Guarda data e hora exatas da visita.
 *
 * Estrutura MVC - camada MODEL
 */
public class Frequencia {

    private Aluno         aluno;
    private LocalDateTime dataHora;

    public Frequencia(Aluno aluno, LocalDateTime dataHora) {
        this.aluno   = aluno;
        this.dataHora = dataHora;
    }

    // --- Getters ---
    public Aluno  getAluno()   { return aluno; }

    public String getDataHoraFormatada() {
        return dataHora.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
    }
}
