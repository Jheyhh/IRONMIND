package service;

import model.Instrutor;
import java.util.ArrayList;
import java.util.List;

/**
 * Gerencia os instrutores da academia.
 * Estrutura MVC - camada SERVICE
 */
public class InstrutorService implements CrudService<Instrutor> {

    private List<Instrutor> instrutores = new ArrayList<>();

    @Override public void         criar(Instrutor i)           { instrutores.add(i); }
    @Override public List<Instrutor> listar()                  { return instrutores; }
    @Override public void         atualizar(int i, Instrutor x){ instrutores.set(i, x); }
    @Override public void         remover(int i)               { instrutores.remove(i); }
}
