package service;

import model.Aluno;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * ============================================================
 *  ESTRUTURAS DE DADOS — IronMind
 *  Todas implementadas 100% manualmente.
 *
 *  E PROIBIDO usar:
 *    - java.util.Queue
 *    - java.util.Stack
 *    - java.util.LinkedList
 *    - Collections.sort()
 *    - Qualquer funcao pronta de ordenacao
 * ============================================================
 *
 *  Estruturas implementadas:
 *    1. FILA   (FIFO) — array circular — aprovacao de alunos
 *    2. PILHA  (LIFO) — array simples  — desfazer exclusao
 *    3. LISTA ENCADEADA — nos manuais  — treino do dia
 *    4. BUBBLE SORT    — por nome      — O(n²)
 *    5. SELECTION SORT — por ID        — O(n²)
 *
 *  Estrutura MVC - camada SERVICE
 */
public class EstruturaDados {

    // =================================================================
    // ESTRUTURA 1: FILA (FIFO) — array circular
    //
    // Comportamento: o primeiro a entrar e o primeiro a sair.
    // Uso no sistema: fila de aprovacao de novos alunos.
    //   - Aluno solicita cadastro → entra no fim da fila.
    //   - Gestor aprova/recusa   → remove do inicio da fila.
    // =================================================================

    /**
     * PedidoInscricao: envelopa o Aluno com a data e hora
     * exatas em que ele entrou na fila de espera.
     */
    public static class PedidoInscricao {

        private Aluno         aluno;
        private LocalDateTime dataHora;

        public PedidoInscricao(Aluno aluno) {
            this.aluno   = aluno;
            this.dataHora = LocalDateTime.now();
        }

        public Aluno  getAluno() { return aluno; }

        public String getDataHoraFormatada() {
            return dataHora.format(
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        }
    }

    private static final int         CAP_FILA   = 100;
    private static PedidoInscricao[] arrayFila  = new PedidoInscricao[CAP_FILA];
    private static int               cabeca     = 0;
    private static int               cauda      = 0;
    private static int               tamFila    = 0;

    /**
     * ENQUEUE — adiciona o aluno no fim da fila.
     * Registra a data e hora automaticamente.
     */
    public static void enfileirar(Aluno aluno) {
        if (tamFila == CAP_FILA) {
            System.out.println("  [FILA] Capacidade maxima atingida!");
            return;
        }
        arrayFila[cauda] = new PedidoInscricao(aluno);
        cauda  = (cauda + 1) % CAP_FILA;
        tamFila++;
    }

    /**
     * DEQUEUE — remove e retorna o aluno do inicio da fila.
     * Retorna null se a fila estiver vazia.
     */
    public static Aluno desenfileirar() {
        if (tamFila == 0) return null;
        PedidoInscricao pedido = arrayFila[cabeca];
        arrayFila[cabeca] = null;
        cabeca  = (cabeca + 1) % CAP_FILA;
        tamFila--;
        return pedido.getAluno();
    }

    /** Retorna quantos pedidos estao na fila no momento. */
    public static int getTamanhoFila() { return tamFila; }

    /**
     * Retorna um pedido da fila por posicao (0 = primeiro)
     * sem remover ninguem. Util para exibir a fila na tela.
     */
    public static PedidoInscricao getPedidoFila(int posicao) {
        if (posicao < 0 || posicao >= tamFila) return null;
        return arrayFila[(cabeca + posicao) % CAP_FILA];
    }


    // =================================================================
    // ESTRUTURA 2: PILHA (LIFO) — array simples com ponteiro topo
    //
    // Comportamento: o ultimo a entrar e o primeiro a sair.
    // Uso no sistema: guarda alunos removidos para permitir desfazer.
    //   - Remover aluno → push (empilha).
    //   - Desfazer      → pop  (desempilha e restaura).
    // =================================================================

    private static final int CAP_PILHA  = 100;
    private static Aluno[]   arrayPilha = new Aluno[CAP_PILHA];
    private static int       topo       = -1;

    /**
     * PUSH — empilha o aluno no topo.
     * Chamado automaticamente ao remover um aluno da lista.
     */
    public static void empilhar(Aluno aluno) {
        if (topo == CAP_PILHA - 1) {
            System.out.println("  [PILHA] Capacidade maxima atingida!");
            return;
        }
        arrayPilha[++topo] = aluno;
    }

    /**
     * POP — retira e retorna o aluno do topo da pilha.
     * Retorna null se a pilha estiver vazia.
     */
    public static Aluno desempilhar() {
        if (topo == -1) return null;
        Aluno aluno      = arrayPilha[topo];
        arrayPilha[topo] = null;
        topo--;
        return aluno;
    }

    /** Retorna quantos alunos estao na pilha (podem ser recuperados). */
    public static int getTamanhoPilha() { return topo + 1; }


    // =================================================================
    // ESTRUTURA 3: LISTA ENCADEADA — nos manuais
    //
    // Comportamento: elementos ligados por ponteiros (sem array).
    // Uso no sistema: plano de treino do dia.
    //   - Cada exercicio e um No com valor e ponteiro para o proximo.
    //   - Percorremos do inicio ao fim imprimindo cada exercicio.
    // =================================================================

    /** No da lista encadeada — guarda o valor e aponta pro proximo. */
    public static class No {
        public String valor;
        public No     proximo;

        public No(String valor) {
            this.valor   = valor;
            this.proximo = null;
        }
    }

    private static No cabecaLista = null;

    /** Adiciona um exercicio no fim da lista encadeada. */
    private static void adicionarExercicio(String exercicio) {
        No novo = new No(exercicio);
        if (cabecaLista == null) {
            cabecaLista = novo;
        } else {
            No atual = cabecaLista;
            while (atual.proximo != null) {
                atual = atual.proximo;
            }
            atual.proximo = novo;
        }
    }

    /**
     * Monta a lista encadeada com os exercicios do dia.
     * Retorna a cabeca da lista para ser percorrida e impressa.
     */
    public static No criarTreinoDoDia() {
        cabecaLista = null;
        adicionarExercicio("Agachamento");
        adicionarExercicio("Supino Reto");
        adicionarExercicio("Leg Press");
        adicionarExercicio("Rosca Direta");
        adicionarExercicio("Abdominais");
        adicionarExercicio("Panturrilha");
        return cabecaLista;
    }

    /**
     * Percorre a lista encadeada do inicio ao fim
     * e imprime cada exercicio do dia.
     */
    public static void imprimirTreino(No cabeca) {
        System.out.println();
        System.out.println("  +------------------------------------------+");
        System.out.println("  |        PLANO DE TREINO DO DIA            |");
        System.out.println("  |    (Lista Encadeada — nos manuais)       |");
        System.out.println("  +------------------------------------------+");
        No  atual = cabeca;
        int num   = 1;
        while (atual != null) {
            System.out.printf("  |  %d. %-38s|%n", num++, atual.valor);
            atual = atual.proximo;
        }
        System.out.println("  +------------------------------------------+");
    }


    // =================================================================
    // ESTRUTURA 4: BUBBLE SORT — ordena por Nome (A ate Z)
    //
    // Complexidade: O(n²)
    // Funcionamento: compara pares adjacentes e troca se necessario.
    //   Repete ate nao haver mais trocas.
    // Uso no sistema: ordena a lista de alunos por nome
    //   para facilitar a busca visual na recepcao.
    // =================================================================

    public static void bubbleSortPorNome(Aluno[] alunos, int tamanho) {
        for (int i = 0; i < tamanho - 1; i++) {
            for (int j = 0; j < tamanho - i - 1; j++) {
                if (alunos[j].getNome()
                             .compareToIgnoreCase(alunos[j + 1].getNome()) > 0) {
                    // Troca os dois alunos de posicao
                    Aluno temp     = alunos[j];
                    alunos[j]      = alunos[j + 1];
                    alunos[j + 1]  = temp;
                }
            }
        }
    }


    // =================================================================
    // ESTRUTURA 5: SELECTION SORT — ordena por ID (crescente)
    //
    // Complexidade: O(n²)
    // Funcionamento: encontra o menor elemento do trecho nao ordenado
    //   e o move para a posicao correta. Repete para o restante.
    // Uso no sistema: reordena a lista de alunos pelo numero de ID
    //   (ordem original de cadastro).
    // =================================================================

    public static void selectionSortPorId(Aluno[] alunos, int tamanho) {
        for (int i = 0; i < tamanho - 1; i++) {
            int menorIdx = i;
            for (int j = i + 1; j < tamanho; j++) {
                if (alunos[j].getId() < alunos[menorIdx].getId()) {
                    menorIdx = j;
                }
            }
            // Troca o menor encontrado com a posicao atual
            Aluno temp          = alunos[menorIdx];
            alunos[menorIdx]    = alunos[i];
            alunos[i]           = temp;
        }
    }
}
