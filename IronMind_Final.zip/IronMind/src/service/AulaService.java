package service;

import model.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Gerencia as aulas e inscricoes de alunos.
 * Estrutura MVC - camada SERVICE
 */
public class AulaService implements CrudService<Aula> {

    private List<Aula> aulas = new ArrayList<>();

    @Override public void      criar(Aula a)           { aulas.add(a); }
    @Override public List<Aula> listar()               { return aulas; }
    @Override public void      atualizar(int i, Aula a){ aulas.set(i, a); }
    @Override public void      remover(int i)          { aulas.remove(i); }

    /**
     * Inscreve um aluno em uma aula.
     * Valida: plano vencido, aula lotada e conflito de horario.
     * Retorna true se a inscricao foi realizada com sucesso.
     */
    public boolean inscrever(Aluno aluno, Aula aula) {

        // Verifica se o plano do aluno ainda e valido
        LocalDate vencimento = aluno.getDataMatricula()
                .plusMonths(aluno.getPlano().getDuracaoMeses());

        if (LocalDate.now().isAfter(vencimento)) {
            System.out.println("  [ERRO] O plano deste aluno venceu em: " + vencimento);
            return false;
        }

        // Verifica se a aula ainda tem vagas
        if (aula.estaLotada()) {
            System.out.println("  [ERRO] Esta aula esta lotada. Sem vagas disponiveis.");
            return false;
        }

        // Verifica se o aluno ja esta inscrito nesta aula
        for (InscricaoAula i : aluno.getInscricoes()) {
            if (i.getAula().getNome().equals(aula.getNome())) {
                System.out.println("  [ERRO] Este aluno ja esta inscrito nesta aula.");
                return false;
            }
        }

        // Cria a inscricao com data e hora automaticas
        InscricaoAula nova = new InscricaoAula(aluno, aula);
        aluno.adicionarInscricao(nova);
        aula.getInscricoes().add(nova);
        return true;
    }
}
