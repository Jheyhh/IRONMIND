package service;

import model.Plano;
import java.util.ArrayList;
import java.util.List;

/**
 * Gerencia os planos da academia.
 * Estrutura MVC - camada SERVICE
 */
public class PlanoService implements CrudService<Plano> {

    private List<Plano> planos = new ArrayList<>();

    @Override public void    criar(Plano p)              { planos.add(p); }
    @Override public List<Plano> listar()                { return planos; }
    @Override public void    atualizar(int i, Plano p)   { planos.set(i, p); }
    @Override public void    remover(int i)              { planos.remove(i); }
}
