package service;

import model.Aluno;
import model.Frequencia;
import java.time.LocalDateTime;

/**
 * Registra entradas (frequencias) dos alunos na academia.
 * Estrutura MVC - camada SERVICE
 */
public class FrequenciaService {

    public void registrarEntrada(Aluno aluno) {
        Frequencia f = new Frequencia(aluno, LocalDateTime.now());
        aluno.adicionarFrequencia(f);
    }
}
