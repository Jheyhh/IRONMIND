package service;

import model.Aluno;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Gerencia os alunos matriculados, a fila de espera e a pilha de desfazer.
 * Faz a ponte entre o Menu (VIEW) e as estruturas de dados (EstruturaDados).
 *
 * Estrutura MVC - camada SERVICE
 */
public class AlunoService implements CrudService<Aluno> {

    private List<Aluno> alunos = new ArrayList<>();

    @Override public void       criar(Aluno a)          { alunos.add(a); }
    @Override public List<Aluno> listar()               { return alunos; }
    @Override public void       atualizar(int i, Aluno a){ alunos.set(i, a); }

    /**
     * Remove o aluno da lista e o salva na PILHA.
     * Assim ele pode ser recuperado depois pela opcao de desfazer.
     */
    @Override
    public void remover(int indice) {
        EstruturaDados.empilhar(alunos.get(indice));
        alunos.remove(indice);
    }

    // ------------------------------------------------------------------
    // FILA — solicitar e aprovar cadastro
    // ------------------------------------------------------------------

    /**
     * Coloca o aluno na FILA de espera para aprovacao.
     * Registra data e hora automaticamente dentro de PedidoInscricao.
     */
    public void solicitarCadastro(Aluno aluno) {
        EstruturaDados.enfileirar(aluno);
    }

    /**
     * Retira o primeiro da FILA e o matricula oficialmente.
     * Chamado quando o gestor aprova o proximo da fila.
     */
    public Aluno aprovarProximo() {
        Aluno aprovado = EstruturaDados.desenfileirar();
        if (aprovado != null) {
            alunos.add(aprovado);
        }
        return aprovado;
    }

    /**
     * Retira o primeiro da FILA e descarta.
     * Chamado quando o gestor recusa o proximo da fila.
     */
    public Aluno recusarProximo() {
        return EstruturaDados.desenfileirar();
    }

    // ------------------------------------------------------------------
    // PILHA — desfazer exclusao
    // ------------------------------------------------------------------

    /**
     * Recupera o ultimo aluno excluido (POP da pilha)
     * e o devolve para a lista de matriculados.
     */
    public Aluno recuperarUltimoExcluido() {
        Aluno recuperado = EstruturaDados.desempilhar();
        if (recuperado != null) {
            alunos.add(recuperado);
        }
        return recuperado;
    }

    // ------------------------------------------------------------------
    // ORDENACAO — Bubble Sort e Selection Sort (sem biblioteca)
    // ------------------------------------------------------------------

    /**
     * Ordena a lista de alunos por nome usando BUBBLE SORT.
     * Complexidade: O(n²).
     */
    public void ordenarPorNome() {
        Aluno[] arr = alunos.toArray(new Aluno[0]);
        EstruturaDados.bubbleSortPorNome(arr, arr.length);
        alunos.clear();
        for (Aluno a : arr) alunos.add(a);
    }

    /**
     * Ordena a lista de alunos por ID usando SELECTION SORT.
     * Complexidade: O(n²).
     */
    public void ordenarPorId() {
        Aluno[] arr = alunos.toArray(new Aluno[0]);
        EstruturaDados.selectionSortPorId(arr, arr.length);
        alunos.clear();
        for (Aluno a : arr) alunos.add(a);
    }

    // ------------------------------------------------------------------
    // VALIDACOES
    // ------------------------------------------------------------------

    /** Retorna true se o plano do aluno ainda esta dentro do prazo. */
    public boolean planoAtivo(Aluno aluno) {
        LocalDate vencimento = aluno.getDataMatricula()
                .plusMonths(aluno.getPlano().getDuracaoMeses());
        return !LocalDate.now().isAfter(vencimento);
    }

    /** Retorna a data de vencimento do plano do aluno. */
    public LocalDate getVencimento(Aluno aluno) {
        return aluno.getDataMatricula()
                .plusMonths(aluno.getPlano().getDuracaoMeses());
    }
}
