package service;

import java.util.List;

/**
 * Interface generica de CRUD usada por todos os services.
 * Define as operacoes basicas: criar, listar, atualizar e remover.
 *
 * Estrutura MVC - camada SERVICE
 */
public interface CrudService<T> {
    void    criar(T objeto);
    List<T> listar();
    void    atualizar(int indice, T objeto);
    void    remover(int indice);
}
