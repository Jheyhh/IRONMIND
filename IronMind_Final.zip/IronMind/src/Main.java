import view.Menu;

/**
 * Ponto de entrada do sistema IronMind.
 * Instancia o Menu e inicia a aplicacao.
 */
public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.iniciar();
    }
}
