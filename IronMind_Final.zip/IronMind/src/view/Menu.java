package view;

import model.*;
import service.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

/**
 * Interface de usuario do sistema IronMind.
 * Estrutura MVC — camada VIEW
 */
public class Menu {

    private final Scanner          sc                = new Scanner(System.in);
    private final AlunoService     alunoService      = new AlunoService();
    private final InstrutorService instrutorService  = new InstrutorService();
    private final PlanoService     planoService      = new PlanoService();
    private final AulaService      aulaService       = new AulaService();
    private final FrequenciaService frequenciaService = new FrequenciaService();

    // ==================================================================
    // MENU PRINCIPAL
    // ==================================================================

    public void iniciar() {
        int op;
        do {
            cls();
            // Barra de status mostra o que ja foi cadastrado
            System.out.println("  +================================================+");
            System.out.println("  |       BEM-VINDO AO IRONMIND ACADEMIA           |");
            System.out.println("  +------------------------------------------------+");
            System.out.printf( "  |  Planos: %-3d | Instrutores: %-3d | Alunos: %-5d |%n",
                    planoService.listar().size(),
                    instrutorService.listar().size(),
                    alunoService.listar().size());
            System.out.printf( "  |  Aulas:  %-3d | Fila espera: %-3d               |%n",
                    aulaService.listar().size(),
                    EstruturaDados.getTamanhoFila());
            System.out.println("  +================================================+");

            // Aviso de primeiros passos quando o sistema esta vazio
            if (planoService.listar().isEmpty()) {
                System.out.println("  | >> COMECE POR AQUI: cadastre um Plano (op.3) |");
                System.out.println("  |    depois um Instrutor (op.2) e uma Aula (4) |");
                System.out.println("  |    Por ultimo cadastre o Aluno (op.1)        |");
                System.out.println("  +------------------------------------------------+");
            }

            System.out.println("  |  ORDEM RECOMENDADA DE USO:                     |");
            System.out.println("  |  3 Planos -> 2 Instrutores -> 4 Aulas -> 1 Alunos|");
            System.out.println("  +================================================+");
            System.out.println("  |  1  Gerenciar Alunos                           |");
            System.out.println("  |  2  Gerenciar Instrutores                      |");
            System.out.println("  |  3  Gerenciar Planos  << COMECE AQUI           |");
            System.out.println("  |  4  Gerenciar Aulas                            |");
            System.out.println("  |  5  Inscrever Aluno em Aula                    |");
            System.out.println("  |  6  Registrar Entrada de Aluno                 |");
            System.out.println("  |  7  Fila de Espera (Aprovar / Recusar)         |");
            System.out.println("  |  8  Recuperar Aluno Excluido por Engano        |");
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  0  Sair do Sistema                            |");
            System.out.println("  +================================================+");
            System.out.print("\n  Digite o numero da opcao: ");

            op = lerOpcao(0, 8);
            cls();

            switch (op) {
                case 1 -> menuAluno();
                case 2 -> menuInstrutor();
                case 3 -> menuPlano();
                case 4 -> menuAula();
                case 5 -> menuInscreverAluno();
                case 6 -> menuFrequencia();
                case 7 -> menuFila();
                case 8 -> menuDesfazer();
                case 0 -> System.out.println("  Encerrando o sistema. Ate logo!");
            }

            if (op != 0) pausar();

        } while (op != 0);
    }

    // ==================================================================
    // MENU ALUNOS
    // ==================================================================

    private void menuAluno() {
        int op;
        do {
            cls();
            System.out.println("  +================================================+");
            System.out.println("  |                MENU DE ALUNOS                  |");
            System.out.println("  +------------------------------------------------+");
            System.out.printf( "  |  Alunos matriculados: %-3d | Na fila: %-3d        |%n",
                    alunoService.listar().size(),
                    EstruturaDados.getTamanhoFila());
            System.out.println("  +------------------------------------------------+");

            // Aviso se nao ha plano cadastrado
            if (planoService.listar().isEmpty()) {
                System.out.println("  | >> ATENCAO: Nenhum plano cadastrado ainda!    |");
                System.out.println("  |    Va ao Menu Principal > opcao 3 primeiro.  |");
                System.out.println("  +------------------------------------------------+");
            }

            System.out.println("  |  1  Cadastrar Novo Aluno (vai para fila)       |");
            System.out.println("  |  2  Ver Lista de Alunos Matriculados           |");
            System.out.println("  |  3  Ordenar por Nome A-Z  (Bubble Sort)        |");
            System.out.println("  |  4  Ordenar por Numero de Cadastro (Selection) |");
            System.out.println("  |  5  Ver Treino do Dia (Lista Encadeada)        |");
            System.out.println("  |  6  Ver Inscricoes de um Aluno                 |");
            System.out.println("  |  7  Remover Aluno (recuperavel depois)         |");
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  0  Voltar ao Menu Principal                   |");
            System.out.println("  +================================================+");
            System.out.print("\n  Digite o numero da opcao: ");

            op = lerOpcao(0, 7);
            cls();

            switch (op) {
                case 1 -> cadastrarNaFila();
                case 2 -> listarAlunos();
                case 3 -> {
                    if (alunoService.listar().isEmpty()) {
                        aviso("Nenhum aluno matriculado para ordenar.");
                    } else {
                        alunoService.ordenarPorNome();
                        ok("Lista ordenada por nome (Bubble Sort).");
                        System.out.println();
                        listarAlunos();
                    }
                }
                case 4 -> {
                    if (alunoService.listar().isEmpty()) {
                        aviso("Nenhum aluno matriculado para ordenar.");
                    } else {
                        alunoService.ordenarPorId();
                        ok("Lista ordenada por numero de cadastro (Selection Sort).");
                        System.out.println();
                        listarAlunos();
                    }
                }
                case 5 -> EstruturaDados.imprimirTreino(EstruturaDados.criarTreinoDoDia());
                case 6 -> verInscricoesAluno();
                case 7 -> removerAluno();
            }

            if (op != 0) pausar();

        } while (op != 0);
    }

    // ------------------------------------------------------------------
    private void cadastrarNaFila() {
        System.out.println("  +================================================+");
        System.out.println("  |          CADASTRAR NOVO ALUNO                  |");
        System.out.println("  |  O aluno entra na FILA DE ESPERA.              |");
        System.out.println("  |  Depois va ao menu principal > op.7 para       |");
        System.out.println("  |  APROVAR ou RECUSAR o cadastro.                |");
        System.out.println("  +================================================+");
        System.out.println();

        if (planoService.listar().isEmpty()) {
            aviso("Nenhum plano cadastrado ainda!");
            System.out.println();
            System.out.println("  Para cadastrar um aluno voce precisa ter");
            System.out.println("  pelo menos um PLANO cadastrado antes.");
            System.out.println();
            System.out.println("  COMO FAZER:");
            System.out.println("  1. Pressione ENTER para voltar");
            System.out.println("  2. Va ao Menu Principal");
            System.out.println("  3. Escolha a opcao 3 (Gerenciar Planos)");
            System.out.println("  4. Cadastre um plano");
            System.out.println("  5. Volte aqui e cadastre o aluno");
            return;
        }

        System.out.println("  Preencha os dados do novo aluno:");
        System.out.println("  (Digite cada informacao e pressione ENTER)");
        System.out.println();
        sc.nextLine();
        System.out.print("  Nome completo  : "); String nome = sc.nextLine().trim();
        System.out.print("  CPF            : "); String cpf  = sc.nextLine().trim();
        System.out.print("  Telefone       : "); String tel  = sc.nextLine().trim();
        System.out.print("  E-mail         : "); String mail = sc.nextLine().trim();

        if (nome.isEmpty() || cpf.isEmpty()) {
            System.out.println();
            aviso("Nome e CPF sao obrigatorios. Cadastro cancelado.");
            return;
        }

        System.out.println();
        System.out.println("  PLANOS DISPONIVEIS:");
        System.out.println("  ------------------------------------------------");
        for (int i = 0; i < planoService.listar().size(); i++) {
            Plano p = planoService.listar().get(i);
            System.out.printf("  %d  %-20s | R$%.2f/mes | %d mes(es)%n",
                    i + 1, p.getNome(), p.getValorMensal(), p.getDuracaoMeses());
        }
        System.out.println("  ------------------------------------------------");
        System.out.print("  Numero do plano: ");
        int idx = lerOpcao(1, planoService.listar().size()) - 1;

        Plano plano = planoService.listar().get(idx);
        if (mail.isEmpty() || !mail.contains("@")) mail = "nao@informado.com";

        Aluno aluno = new Aluno(nome, cpf, tel, LocalDate.now(),
                                mail, LocalDate.now(), plano);
        alunoService.solicitarCadastro(aluno);

        System.out.println();
        System.out.println("  +================================================+");
        System.out.println("  |  [OK] CADASTRO REALIZADO!                      |");
        System.out.println("  +------------------------------------------------+");
        System.out.println("  |  Nome   : " + padDir(nome, 37) + "|");
        System.out.println("  |  Plano  : " + padDir(plano.getNome(), 37) + "|");
        System.out.println("  |  Status : Aguardando aprovacao na fila         |");
        System.out.println("  +------------------------------------------------+");
        System.out.println("  |  PROXIMO PASSO:                                |");
        System.out.println("  |  Va ao Menu Principal > opcao 7                |");
        System.out.println("  |  para APROVAR ou RECUSAR este cadastro.        |");
        System.out.println("  +================================================+");
    }

    // ------------------------------------------------------------------
    private void listarAlunos() {
        System.out.println("  ALUNOS MATRICULADOS:");
        System.out.println();

        if (alunoService.listar().isEmpty()) {
            aviso("Nenhum aluno matriculado ainda.");
            System.out.println();
            System.out.println("  COMO CADASTRAR UM ALUNO:");
            System.out.println("  1. Primeiro cadastre um Plano (Menu Principal > op.3)");
            System.out.println("  2. Depois cadastre o Aluno   (este menu > op.1)");
            System.out.println("  3. Aprove o cadastro         (Menu Principal > op.7)");
            return;
        }

        System.out.printf("  %-4s %-5s %-22s %-15s %-12s %-8s%n",
                "Num", "ID", "Nome", "Plano", "Vencimento", "Situacao");
        System.out.println("  -----------------------------------------------------------------------");
        for (int i = 0; i < alunoService.listar().size(); i++) {
            Aluno a = alunoService.listar().get(i);
            System.out.printf("  %-4d %-5d %-22s %-15s %-12s %-8s%n",
                    i + 1, a.getId(), a.getNome(),
                    a.getPlano().getNome(),
                    alunoService.getVencimento(a),
                    alunoService.planoAtivo(a) ? "ATIVO" : "VENCIDO");
        }
        System.out.println("  -----------------------------------------------------------------------");
        System.out.println("  Total: " + alunoService.listar().size() + " aluno(s) matriculado(s).");
    }

    // ------------------------------------------------------------------
    private void verInscricoesAluno() {
        System.out.println("  INSCRICOES DE UM ALUNO EM AULAS:");
        System.out.println();

        if (alunoService.listar().isEmpty()) {
            aviso("Nenhum aluno matriculado.");
            return;
        }

        listarAlunos();
        System.out.println();
        System.out.print("  Numero do aluno (coluna Num): ");
        int idx = lerOpcao(1, alunoService.listar().size()) - 1;
        Aluno aluno = alunoService.listar().get(idx);

        System.out.println();
        System.out.println("  Aluno: " + aluno.getNome());
        System.out.println("  -----------------------------------------------");

        if (aluno.getInscricoes().isEmpty()) {
            aviso("Este aluno nao esta inscrito em nenhuma aula ainda.");
            System.out.println("  Use o Menu Principal > opcao 5 para inscrever.");
            return;
        }

        System.out.printf("  %-4s %-22s %-24s%n",
                "Num", "Aula", "Data e Hora da Inscricao");
        System.out.println("  -----------------------------------------------");
        for (int i = 0; i < aluno.getInscricoes().size(); i++) {
            InscricaoAula ins = aluno.getInscricoes().get(i);
            System.out.printf("  %-4d %-22s %-24s%n",
                    i + 1,
                    ins.getAula().getNome(),
                    ins.getDataHoraFormatada());
        }
        System.out.println("  -----------------------------------------------");
        System.out.println("  Total: " + aluno.getInscricoes().size() + " inscricao(oes).");
    }

    // ------------------------------------------------------------------
    private void removerAluno() {
        System.out.println("  REMOVER ALUNO:");
        System.out.println("  (O aluno sera salvo e podera ser recuperado");
        System.out.println("   pelo Menu Principal > opcao 8)");
        System.out.println();

        listarAlunos();
        if (alunoService.listar().isEmpty()) return;

        System.out.println();
        System.out.print("  Numero do aluno que deseja remover (coluna Num): ");
        int num = lerOpcao(1, alunoService.listar().size());
        String nome = alunoService.listar().get(num - 1).getNome();

        System.out.println();
        System.out.println("  Voce escolheu remover: " + nome);
        System.out.print("  Confirma a remocao? (S = Sim / N = Nao): ");

        if (lerSN().equals("S")) {
            alunoService.remover(num - 1);
            System.out.println();
            ok(nome + " foi removido.");
            System.out.println("  Para desfazer: Menu Principal > opcao 8.");
        } else {
            System.out.println();
            System.out.println("  Cancelado. Nenhum aluno foi removido.");
        }
    }

    // ==================================================================
    // FILA DE ESPERA
    // ==================================================================

    private void menuFila() {
        System.out.println("  +================================================+");
        System.out.println("  |   FILA DE ESPERA — APROVACAO DE NOVOS ALUNOS  |");
        System.out.println("  |   Quem entrou primeiro e atendido primeiro.    |");
        System.out.println("  +================================================+");
        System.out.println();

        int tam = EstruturaDados.getTamanhoFila();

        if (tam == 0) {
            aviso("Nenhum aluno aguardando aprovacao.");
            System.out.println();
            System.out.println("  Para adicionar alunos a fila:");
            System.out.println("  Menu Alunos (op.1) > Cadastrar Novo Aluno (op.1)");
            return;
        }

        System.out.println("  Ha " + tam + " aluno(s) aguardando aprovacao:");
        System.out.println();
        System.out.printf("  %-4s %-22s %-24s %-15s%n",
                "Pos", "Nome", "Entrou na fila em", "Plano");
        System.out.println("  -----------------------------------------------------------------------");
        for (int i = 0; i < tam; i++) {
            EstruturaDados.PedidoInscricao p = EstruturaDados.getPedidoFila(i);
            System.out.printf("  %-4d %-22s %-24s %-15s%n",
                    i + 1,
                    p.getAluno().getNome(),
                    p.getDataHoraFormatada(),
                    p.getAluno().getPlano().getNome());
        }
        System.out.println("  -----------------------------------------------------------------------");
        System.out.println();

        EstruturaDados.PedidoInscricao prim = EstruturaDados.getPedidoFila(0);
        System.out.println("  AVALIANDO O PRIMEIRO DA FILA:");
        System.out.println("  Nome   : " + prim.getAluno().getNome());
        System.out.println("  Entrou : " + prim.getDataHoraFormatada());
        System.out.println("  Plano  : " + prim.getAluno().getPlano().getNome());
        System.out.println();
        System.out.println("  O QUE DESEJA FAZER?");
        System.out.println("  ------------------------------------------------");
        System.out.println("  1  APROVAR  — aluno e matriculado agora");
        System.out.println("  2  RECUSAR  — pedido descartado da fila");
        System.out.println("  0  Voltar   — nenhuma acao agora");
        System.out.println("  ------------------------------------------------");
        System.out.print("  Escolha: ");

        int op = lerOpcao(0, 2);
        System.out.println();

        if (op == 1) {
            Aluno aprovado = alunoService.aprovarProximo();
            if (aprovado != null) {
                System.out.println("  +================================================+");
                ok("ALUNO APROVADO E MATRICULADO!");
                System.out.println("  |  Nome  : " + aprovado.getNome());
                System.out.println("  |  Plano : " + aprovado.getPlano().getNome());
                System.out.println("  +------------------------------------------------+");
                System.out.println("  |  PROXIMO PASSO:                                |");
                System.out.println("  |  Inscreva o aluno em uma aula (op.5 do menu)  |");
                System.out.println("  +================================================+");
            }
        } else if (op == 2) {
            Aluno recusado = alunoService.recusarProximo();
            if (recusado != null) {
                aviso("Pedido de " + recusado.getNome() + " recusado e descartado.");
            }
        } else {
            System.out.println("  Nenhuma acao realizada.");
        }
    }

    // ==================================================================
    // DESFAZER (PILHA)
    // ==================================================================

    private void menuDesfazer() {
        System.out.println("  +================================================+");
        System.out.println("  |     RECUPERAR ALUNO EXCLUIDO POR ENGANO        |");
        System.out.println("  |     O ultimo aluno removido sera restaurado.   |");
        System.out.println("  +================================================+");
        System.out.println();

        int tam = EstruturaDados.getTamanhoPilha();
        if (tam == 0) {
            aviso("Nenhum aluno foi excluido recentemente.");
            System.out.println("  Nao ha nada para recuperar no momento.");
            return;
        }

        System.out.println("  Ha " + tam + " exclusao(oes) que podem ser desfeitas.");
        System.out.println();
        System.out.print("  Deseja recuperar o ultimo aluno removido? (S = Sim / N = Nao): ");

        if (lerSN().equals("S")) {
            Aluno rec = alunoService.recuperarUltimoExcluido();
            System.out.println();
            if (rec != null) ok(rec.getNome() + " foi restaurado e esta matriculado novamente!");
        } else {
            System.out.println();
            System.out.println("  Cancelado. Nenhum aluno foi recuperado.");
        }
    }

    // ==================================================================
    // MENU INSTRUTOR
    // ==================================================================

    private void menuInstrutor() {
        int op;
        do {
            cls();
            System.out.println("  +================================================+");
            System.out.println("  |             MENU DE INSTRUTORES                |");
            System.out.println("  +------------------------------------------------+");
            System.out.printf( "  |  Instrutores cadastrados: %-3d                  |%n",
                    instrutorService.listar().size());
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  DICA: Cadastre o instrutor antes de criar     |");
            System.out.println("  |  uma aula, pois a aula precisa de instrutor.   |");
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  1  Cadastrar Novo Instrutor                   |");
            System.out.println("  |  2  Ver Lista de Instrutores                   |");
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  0  Voltar ao Menu Principal                   |");
            System.out.println("  +================================================+");
            System.out.print("\n  Digite o numero da opcao: ");

            op = lerOpcao(0, 2);
            cls();

            if (op == 1) {
                System.out.println("  CADASTRAR NOVO INSTRUTOR:");
                System.out.println("  (Preencha os dados e pressione ENTER em cada campo)");
                System.out.println();
                sc.nextLine();
                System.out.print("  Nome completo  : "); String n = sc.nextLine().trim();
                System.out.print("  CPF            : "); String c = sc.nextLine().trim();
                System.out.print("  Telefone       : "); String t = sc.nextLine().trim();
                System.out.print("  Especialidade  : "); String e = sc.nextLine().trim();
                System.out.print("  Horario        : "); String h = sc.nextLine().trim();

                if (n.isEmpty() || c.isEmpty()) {
                    System.out.println();
                    aviso("Nome e CPF sao obrigatorios. Cadastro cancelado.");
                } else {
                    instrutorService.criar(new Instrutor(n, c, t, e, h));
                    System.out.println();
                    ok("Instrutor " + n + " cadastrado!");
                    System.out.println("  PROXIMO PASSO: Va ao Menu Principal > op.4 para cadastrar uma aula.");
                }
                pausar();

            } else if (op == 2) {
                System.out.println("  LISTA DE INSTRUTORES:");
                System.out.println();
                if (instrutorService.listar().isEmpty()) {
                    aviso("Nenhum instrutor cadastrado ainda.");
                } else {
                    System.out.printf("  %-4s %-5s %-22s %-20s%n",
                            "Num", "ID", "Nome", "Especialidade");
                    System.out.println("  -----------------------------------------------");
                    for (int i = 0; i < instrutorService.listar().size(); i++) {
                        Instrutor inst = instrutorService.listar().get(i);
                        System.out.printf("  %-4d %-5d %-22s %-20s%n",
                                i + 1, inst.getId(),
                                inst.getNome(), inst.getEspecialidade());
                    }
                    System.out.println("  -----------------------------------------------");
                }
                pausar();
            }

        } while (op != 0);
    }

    // ==================================================================
    // MENU PLANO
    // ==================================================================

    private void menuPlano() {
        int op;
        do {
            cls();
            System.out.println("  +================================================+");
            System.out.println("  |               MENU DE PLANOS                   |");
            System.out.println("  +------------------------------------------------+");
            System.out.printf( "  |  Planos cadastrados: %-3d                       |%n",
                    planoService.listar().size());
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  DICA: O plano e obrigatorio para cadastrar    |");
            System.out.println("  |  um aluno. Comece cadastrando um plano aqui.   |");
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  1  Cadastrar Novo Plano                       |");
            System.out.println("  |  2  Ver Lista de Planos                        |");
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  0  Voltar ao Menu Principal                   |");
            System.out.println("  +================================================+");
            System.out.print("\n  Digite o numero da opcao: ");

            op = lerOpcao(0, 2);
            cls();

            if (op == 1) {
                System.out.println("  CADASTRAR NOVO PLANO:");
                System.out.println("  (Preencha os dados e pressione ENTER em cada campo)");
                System.out.println();
                sc.nextLine();
                System.out.print("  Nome do plano      : "); String n = sc.nextLine().trim();
                System.out.print("  Descricao          : "); String d = sc.nextLine().trim();
                System.out.print("  Valor mensal (R$)  : "); double v = lerDouble();
                sc.nextLine();
                System.out.print("  Beneficios         : "); String b = sc.nextLine().trim();
                System.out.print("  Duracao (meses)    : "); int m = lerOpcao(1, 60);

                if (n.isEmpty()) {
                    System.out.println();
                    aviso("Nome obrigatorio. Cadastro cancelado.");
                } else {
                    planoService.criar(new Plano(n, d, v, b, m));
                    System.out.println();
                    ok("Plano '" + n + "' cadastrado!");
                    System.out.println("  PROXIMO PASSO: Va ao Menu Principal > op.2 para cadastrar um Instrutor.");
                }
                pausar();

            } else if (op == 2) {
                System.out.println("  LISTA DE PLANOS:");
                System.out.println();
                if (planoService.listar().isEmpty()) {
                    aviso("Nenhum plano cadastrado ainda.");
                } else {
                    System.out.printf("  %-4s %-22s %-14s %-8s%n",
                            "Num", "Nome", "Valor/mes", "Meses");
                    System.out.println("  -----------------------------------------------");
                    for (int i = 0; i < planoService.listar().size(); i++) {
                        Plano p = planoService.listar().get(i);
                        System.out.printf("  %-4d %-22s R$%-12.2f %-8d%n",
                                i + 1, p.getNome(), p.getValorMensal(), p.getDuracaoMeses());
                    }
                    System.out.println("  -----------------------------------------------");
                }
                pausar();
            }

        } while (op != 0);
    }

    // ==================================================================
    // MENU AULA
    // ==================================================================

    private void menuAula() {
        int op;
        do {
            cls();
            System.out.println("  +================================================+");
            System.out.println("  |                MENU DE AULAS                   |");
            System.out.println("  +------------------------------------------------+");
            System.out.printf( "  |  Aulas cadastradas: %-3d | Instrutores: %-3d      |%n",
                    aulaService.listar().size(),
                    instrutorService.listar().size());
            System.out.println("  +------------------------------------------------+");

            if (instrutorService.listar().isEmpty()) {
                System.out.println("  | >> ATENCAO: Nenhum instrutor cadastrado!      |");
                System.out.println("  |    Va ao Menu Principal > op.2 primeiro.     |");
                System.out.println("  +------------------------------------------------+");
            }

            System.out.println("  |  1  Cadastrar Nova Aula                        |");
            System.out.println("  |  2  Ver Lista de Aulas                         |");
            System.out.println("  +------------------------------------------------+");
            System.out.println("  |  0  Voltar ao Menu Principal                   |");
            System.out.println("  +================================================+");
            System.out.print("\n  Digite o numero da opcao: ");

            op = lerOpcao(0, 2);
            cls();

            if (op == 1) {
                System.out.println("  CADASTRAR NOVA AULA:");
                System.out.println();

                if (instrutorService.listar().isEmpty()) {
                    aviso("Nenhum instrutor cadastrado!");
                    System.out.println();
                    System.out.println("  Voce precisa cadastrar um instrutor antes de criar uma aula.");
                    System.out.println("  COMO FAZER:");
                    System.out.println("  1. Pressione ENTER para voltar");
                    System.out.println("  2. Va ao Menu Principal");
                    System.out.println("  3. Escolha a opcao 2 (Gerenciar Instrutores)");
                    System.out.println("  4. Cadastre um instrutor");
                    System.out.println("  5. Volte aqui e crie a aula");
                    pausar();
                    continue;
                }

                sc.nextLine();
                System.out.print("  Nome da aula       : "); String n = sc.nextLine().trim();
                System.out.print("  Descricao          : "); String d = sc.nextLine().trim();
                System.out.print("  Duracao (minutos)  : "); int dur = lerOpcao(1, 300);
                System.out.print("  Vagas disponiveis  : "); int cap = lerOpcao(1, 500);

                System.out.println();
                System.out.println("  INSTRUTORES DISPONIVEIS:");
                System.out.println("  -----------------------------------------------");
                for (int i = 0; i < instrutorService.listar().size(); i++) {
                    Instrutor inst = instrutorService.listar().get(i);
                    System.out.printf("  %d  %-22s  %s%n",
                            i + 1, inst.getNome(), inst.getEspecialidade());
                }
                System.out.println("  -----------------------------------------------");
                System.out.print("  Numero do instrutor: ");
                int idxI = lerOpcao(1, instrutorService.listar().size()) - 1;
                Instrutor inst = instrutorService.listar().get(idxI);

                aulaService.criar(new Aula(n, d, dur,
                        LocalDateTime.now().plusDays(1), cap, inst));
                System.out.println();
                ok("Aula '" + n + "' cadastrada! Instrutor: " + inst.getNome() + " | Vagas: " + cap);
                System.out.println("  PROXIMO PASSO: Cadastre um aluno (op.1) e depois inscreva-o na aula (op.5).");
                pausar();

            } else if (op == 2) {
                System.out.println("  LISTA DE AULAS:");
                System.out.println();
                if (aulaService.listar().isEmpty()) {
                    aviso("Nenhuma aula cadastrada ainda.");
                } else {
                    System.out.printf("  %-4s %-22s %-18s %-6s %-8s%n",
                            "Num", "Nome da Aula", "Instrutor", "Vagas", "Duracao");
                    System.out.println("  -----------------------------------------------");
                    for (int i = 0; i < aulaService.listar().size(); i++) {
                        Aula a = aulaService.listar().get(i);
                        System.out.printf("  %-4d %-22s %-18s %-6d %dmin%n",
                                i + 1, a.getNome(),
                                a.getInstrutor().getNome(),
                                a.getVagasRestantes(), a.getDuracao());
                    }
                    System.out.println("  -----------------------------------------------");
                }
                pausar();
            }

        } while (op != 0);
    }

    // ==================================================================
    // INSCRICAO EM AULA
    // ==================================================================

    private void menuInscreverAluno() {
        System.out.println("  +================================================+");
        System.out.println("  |       INSCREVER ALUNO EM UMA AULA              |");
        System.out.println("  |  Data e hora da inscricao ficam registradas.   |");
        System.out.println("  +================================================+");
        System.out.println();

        // Verifica pre-requisitos com instrucoes claras
        if (alunoService.listar().isEmpty()) {
            aviso("Nenhum aluno matriculado ainda.");
            System.out.println();
            System.out.println("  Para inscrever um aluno em uma aula voce precisa:");
            System.out.println("  1. Ter um Plano cadastrado     (Menu Principal > op.3)");
            System.out.println("  2. Ter um Instrutor cadastrado (Menu Principal > op.2)");
            System.out.println("  3. Ter uma Aula cadastrada     (Menu Principal > op.4)");
            System.out.println("  4. Ter um Aluno matriculado    (Menu Principal > op.1 e depois op.7)");
            return;
        }

        if (aulaService.listar().isEmpty()) {
            aviso("Nenhuma aula cadastrada ainda.");
            System.out.println();
            System.out.println("  Para cadastrar uma aula:");
            System.out.println("  1. Ter um Instrutor cadastrado (Menu Principal > op.2)");
            System.out.println("  2. Cadastrar a Aula            (Menu Principal > op.4)");
            return;
        }

        System.out.println("  PASSO 1 — Selecione o aluno:");
        System.out.println();
        listarAlunos();
        System.out.println();
        System.out.print("  Numero do aluno (coluna Num): ");
        int ia = lerOpcao(1, alunoService.listar().size()) - 1;
        Aluno aluno = alunoService.listar().get(ia);

        System.out.println();
        System.out.println("  PASSO 2 — Selecione a aula:");
        System.out.println();
        System.out.printf("  %-4s %-22s %-18s %-6s%n",
                "Num", "Nome da Aula", "Instrutor", "Vagas");
        System.out.println("  -----------------------------------------------");
        for (int i = 0; i < aulaService.listar().size(); i++) {
            Aula a = aulaService.listar().get(i);
            System.out.printf("  %-4d %-22s %-18s %-6d%n",
                    i + 1, a.getNome(),
                    a.getInstrutor().getNome(),
                    a.getVagasRestantes());
        }
        System.out.println("  -----------------------------------------------");
        System.out.print("  Numero da aula (coluna Num): ");
        int iau = lerOpcao(1, aulaService.listar().size()) - 1;
        Aula aula = aulaService.listar().get(iau);

        System.out.println();
        boolean ok = aulaService.inscrever(aluno, aula);
        if (ok) {
            InscricaoAula ins = aluno.getInscricoes()
                    .get(aluno.getInscricoes().size() - 1);
            System.out.println("  +================================================+");
            ok("INSCRICAO REALIZADA COM SUCESSO!");
            System.out.println("  |  Aluno       : " + padDir(aluno.getNome(), 32) + "|");
            System.out.println("  |  Aula        : " + padDir(aula.getNome(), 32) + "|");
            System.out.println("  |  Instrutor   : " + padDir(aula.getInstrutor().getNome(), 32) + "|");
            System.out.println("  |  Inscrito em : " + padDir(ins.getDataHoraFormatada(), 32) + "|");
            System.out.println("  +================================================+");
        }
    }

    // ==================================================================
    // FREQUENCIA
    // ==================================================================

    private void menuFrequencia() {
        System.out.println("  REGISTRAR ENTRADA DE ALUNO:");
        System.out.println("  (Data e hora registradas automaticamente)");
        System.out.println();

        if (alunoService.listar().isEmpty()) {
            aviso("Nenhum aluno matriculado para registrar entrada.");
            return;
        }

        listarAlunos();
        System.out.println();
        System.out.print("  Numero do aluno que esta entrando (coluna Num): ");
        int idx = lerOpcao(1, alunoService.listar().size()) - 1;
        Aluno aluno = alunoService.listar().get(idx);

        frequenciaService.registrarEntrada(aluno);
        Frequencia ult = aluno.getFrequencias().get(aluno.getFrequencias().size() - 1);

        System.out.println();
        ok("Entrada registrada!");
        System.out.println("  Aluno       : " + aluno.getNome());
        System.out.println("  Entrada em  : " + ult.getDataHoraFormatada());
    }

    // ==================================================================
    // UTILITARIOS
    // ==================================================================

    /** Limpa a tela de forma compativel com Windows e Linux. */
    private void cls() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls")
                        .inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Se nao conseguir limpar, imprime poucas linhas para separar
            System.out.println("\n\n\n");
        }
    }

    private void aviso(String msg) {
        System.out.println("  [!] " + msg);
    }

    private void ok(String msg) {
        System.out.println("  [OK] " + msg);
    }

    private void pausar() {
        System.out.println();
        System.out.print("  Pressione ENTER para continuar...");
        sc.nextLine();
    }

    /** Preenche uma String com espacos a direita ate o tamanho informado. */
    private String padDir(String texto, int tamanho) {
        if (texto == null) texto = "";
        if (texto.length() > tamanho) texto = texto.substring(0, tamanho);
        return String.format("%-" + tamanho + "s", texto);
    }

    /**
     * Le um numero inteiro do usuario entre [min] e [max].
     * Se digitar letra  -> avisa que nao e um numero.
     * Se digitar fora   -> avisa opcao invalida.
     * Nunca trava nem lanca excecao.
     */
    private int lerOpcao(int min, int max) {
        while (true) {
            String entrada = sc.next().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor >= min && valor <= max) return valor;
                System.out.printf(
                    "  [!] Opcao invalida. Digite um numero de %d a %d: ",
                    min, max);
            } catch (NumberFormatException e) {
                System.out.printf(
                    "  [!] \"%s\" nao e um numero. Digite de %d a %d: ",
                    entrada, min, max);
            }
        }
    }

    /** Le S ou N. Repete com aviso se digitar outra coisa. */
    private String lerSN() {
        while (true) {
            String entrada = sc.next().trim().toUpperCase();
            if (entrada.equals("S") || entrada.equals("N")) return entrada;
            System.out.print("  [!] Digite S para Sim ou N para Nao: ");
        }
    }

    /** Le um numero decimal positivo. Aceita virgula ou ponto. */
    private double lerDouble() {
        while (true) {
            try {
                double v = Double.parseDouble(
                        sc.next().trim().replace(",", "."));
                if (v > 0) return v;
                System.out.print("  [!] O valor deve ser maior que zero: ");
            } catch (NumberFormatException e) {
                System.out.print("  [!] Isso nao e um numero valido: ");
            }
        }
    }
}
